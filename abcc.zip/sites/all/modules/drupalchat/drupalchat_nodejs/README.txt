Download and install nodejs module.

Setup node.js server as explained in nodejs module.

Copy the drupalchat_nodejs.server.extension.js to the folder where you have stored server.js of nodejs module. 

Configure node.config.js to load the drupalchat_nodejs.server.extension.

Enable this module and go to DrupalChat settings page and change your backend.  

